import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Customerbean } from '../customerbean';


@Component({
  selector: 'app-editcustomer',
  templateUrl: './editcustomer.component.html',
  styleUrls: ['./editcustomer.component.css']
})
export class EditcustomerComponent implements OnInit {

  customerData:Customerbean={"id":0,"email":" ","fullName":" ","phonenumber":" ","password": " ","address":" ","city":" ","state":" ","country":" ", "registeredDate":new Date('yyyy-mmm-dd')}
  constructor(private customerService:CustomerService,private router:Router,private route:ActivatedRoute) { }
  
  ngOnInit() {
    this.route.params.subscribe((params)=>{this.customerService.getCustomer(params['id']).subscribe(
      (result)=>{this.customerData=result;})})
      console.log(this.customerData); 
    }
      edit(){
        console.log(this.customerData.id);
        this.customerService.editcustomer(this.customerData).subscribe((data)=>{this.router.navigate(['showlist'])});
        alert('updated successfully');
        
       }  
  

}
