import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Customerbean } from './customerbean';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
 
url:string="http://localhost:4080/api/";
  constructor(private http:HttpClient) { }
    addCustomer(customer:Customerbean){
      return this.http.post(this.url+"customer",customer);
    }
    getAllCustomers(){
     return this.http.get<Customerbean[]>(this.url+"customer/");
    }
    deleteCustomer(id:number){
   return this.http.delete<Customerbean[]>(this.url+"customer/"+id);
    }
    getCustomer(id:number){
      return this.http.get<Customerbean>(this.url+"customer/"+id);
       }
       editcustomer(customer:Customerbean){
         return this.http.put(this.url+"customer/"+customer.id,customer);
       }

}
