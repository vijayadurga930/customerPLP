import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customerbean } from '../customerbean';
import { CustomerService } from '../customer.service';
@Component({
  selector: 'app-addcustomer',
  templateUrl: './addcustomer.component.html',
  styleUrls: ['./addcustomer.component.css']
})
export class AddcustomerComponent implements OnInit {
  customerData:Customerbean={"id":0,"email":" ","fullName":" ","phonenumber":" ","password": " ","address":" ","city":" ","state":" ","country":" ", "registeredDate":new Date('yyyy-mmm-dd')}
  constructor(private customerService:CustomerService,private router:Router) { }

  ngOnInit() {
  }
  add(){
    console.log(this.customerData.fullName);
    this.customerService.addCustomer(this.customerData).subscribe(
      (data)=>{this.router.navigate(['showlist']);});
  }


}
