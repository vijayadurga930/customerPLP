import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddcustomerComponent } from './addcustomer/addcustomer.component';
import { EditcustomerComponent } from './editcustomer/editcustomer.component';
import { ShowlistComponent } from './showlist/showlist.component';
import { LoginComponent } from './login/login.component';


const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'addcustomer',component:AddcustomerComponent},
  {path:'editcustomer',component:EditcustomerComponent},
  {path:'showlist',component:ShowlistComponent},
  {path:'showlist/editcustomer/editcustomer',component:EditcustomerComponent},
  {path:'showlist/editcustomer/:id' ,component:EditcustomerComponent}



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
