import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';
import { Customerbean } from '../customerbean';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  customerData:Customerbean={"id":0,"email":" ","fullName":" ","phonenumber":" ","password": " ","address":" ","city":" ","state":" ","country":" ", "registeredDate":new Date('yyyy-mmm-dd')}
  constructor(private customerService:CustomerService,private router:Router) { }

  ngOnInit() {
  }
  login()
  {
  var data=sessionStorage.getItem("loginstatus");
  if(data=="success")
  {
  return true;
  
  }else{
  return false;
  }
  }
}
