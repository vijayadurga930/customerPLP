export class Customerbean {
    id:number;
    email:string;
    fullName:string;
    phonenumber:string;
    password:string;
    address:string;
    city:string;
    state:string;
    country:string;
    registeredDate:Date;



}
