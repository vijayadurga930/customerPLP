import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import {  Customerbean} from '../customerbean';
@Component({
  selector: 'app-showlist',
  templateUrl: './showlist.component.html',
  styleUrls: ['./showlist.component.css']
})
export class ShowlistComponent implements OnInit {
  customers:Customerbean[];
  constructor(private customerService:CustomerService) { }

  ngOnInit() {
    this.customerService.getAllCustomers().subscribe(
      (data:Customerbean[])=>{this.customers=data});
     console.log("all" +this.customers)
  }
  delete(id:number){
    this.customerService.deleteCustomer(id).subscribe(
      (data)=>{this.customers=data}
  );
  }

}
