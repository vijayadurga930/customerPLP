package com.capgemini.cust.service;

import java.util.List;

import com.capgemini.cust.dto.Customer;
import com.capgemini.cust.exception.CustomerException;

public interface CustomerService {
	
	List<Customer> getAllCustomers() throws CustomerException;
    List<Customer> addCustomer(Customer customer) throws CustomerException;
   Customer getCustomerById(int id) throws CustomerException;
    List<Customer> deleteCustomer(int id)throws CustomerException;
	List<Customer> updateCustomer(Customer customer, int id) throws CustomerException;
	
}
