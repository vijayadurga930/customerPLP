package com.capgemini.cust.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.cust.dto.Customer;
import com.capgemini.cust.exception.CustomerException;
import com.capgemini.cust.service.CustomerService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api")
public class CustomerController {
	@Autowired
	public CustomerService service;
	
	
	@GetMapping("/customer")
	public List<Customer> getAllCustomers() throws CustomerException{
		return service.getAllCustomers();
	}
	
	 @PostMapping("/customer")
	 
	 public List<Customer> addCustomer(@RequestBody Customer customer) throws CustomerException {
		 return service.addCustomer(customer);
	 }
	 
	 @DeleteMapping("/customer/{id}")
		public List<Customer> deleteCustomer(@PathVariable int id) throws CustomerException {
		 return service.deleteCustomer(id);
	 }

	 @PutMapping("/customer/{id}")
	 public List<Customer> updateCustomer( @RequestBody Customer customer,@PathVariable int id) throws CustomerException {
			return service.updateCustomer( customer,id);	
	 }
	 
	 @GetMapping("/customer/{id}")
	 public Customer getCustomerById(@PathVariable int id) throws CustomerException {
		 return service.getCustomerById(id);
	 }
}
